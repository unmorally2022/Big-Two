using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Readme : MonoBehaviour
{
    /*
    references
    - https://en.wikipedia.org/wiki/List_of_poker_hands
    - http://www.mathcs.emory.edu/~cheung/Courses/170/Syllabus/10/pokerCheck.html
    */

    /*
    select cahracter
    make character expresion when win or loose
    */
}
